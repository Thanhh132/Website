﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ElectroShop.Library
{
    public class ModelThongbao
    {
        public string msg { get; set; }
        public String msg_type { get; set; }
    }
}