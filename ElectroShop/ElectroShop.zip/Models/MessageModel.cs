﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ElectroShop.Models
{
    public class MessageModel
    {
        public string UserMessage { get; set; }
        public string AIResponse { get; set; }      
    }
}